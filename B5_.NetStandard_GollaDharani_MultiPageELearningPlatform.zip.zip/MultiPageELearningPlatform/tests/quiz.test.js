const { calculateGrade, calculatePercentage, isPassed } = require('../js/main');

test("Grade calculation A", () => {
  expect(calculateGrade(85)).toBe("A");
});

test("Grade calculation Fail", () => {
  expect(calculateGrade(20)).toBe("Fail");
});

test("Percentage calculation", () => {
  expect(calculatePercentage(2, 4)).toBe(50);
});

test("Pass logic true", () => {
  expect(isPassed(45)).toBe(true);
});

test("Pass logic false", () => {
  expect(isPassed(30)).toBe(false);
});