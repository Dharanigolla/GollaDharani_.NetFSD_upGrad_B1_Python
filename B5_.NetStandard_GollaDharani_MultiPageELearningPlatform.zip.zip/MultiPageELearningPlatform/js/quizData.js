const quizData = {
HTML: [
{
question:"HTML stands for?",
options:[
"Hyper Text Markup Language",
"High Tool Machine Language",
"Hyperlinks Text Mark",
"None"
],
answer:0
},
{
question:"Which tag creates a table?",
options:["table","tr","td","th"],
answer:0
}
],

JavaScript: [
{
question:"Which keyword declares variable?",
options:["var","int","string","let"],
answer:0
},
{
question:"Which is used for DOM?",
options:["document","window","html","css"],
answer:0
}
],

Git: [
{
question:"Git command to initialize repo?",
options:["git start","git init","git begin","git create"],
answer:1
},
{
question:"Command to save changes?",
options:["git push","git commit","git save","git add"],
answer:1
}
]
};