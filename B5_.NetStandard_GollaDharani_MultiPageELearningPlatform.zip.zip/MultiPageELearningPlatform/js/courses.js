function unlockCourses(){

let completed = parseInt(localStorage.getItem("quizScore")) || 0;

let jsBtn = document.getElementById("jsBtn");
let gitBtn = document.getElementById("gitBtn");

// STOP if buttons not found 
if(!jsBtn || !gitBtn){
return;
}

// lock by default
jsBtn.disabled = true;
gitBtn.disabled = true;

// unlock step-by-step
if(completed >= 1){
jsBtn.disabled = false;
jsBtn.innerText = "Start Quiz";
jsBtn.onclick = () => startQuiz("JavaScript");
}

if(completed >= 2){
gitBtn.disabled = false;
gitBtn.innerText = "Start Quiz";
gitBtn.onclick = () => startQuiz("Git");
}
// update table status
let rows = document.querySelectorAll(".small-table tr");

if(rows.length >= 4){
  // HTML always available
  rows[1].children[1].innerText = "Available";

  // JavaScript
  rows[2].children[1].innerText = completed >= 1 ? "Available" : "Locked";

  // Git
  rows[3].children[1].innerText = completed >= 2 ? "Available" : "Locked";
}

}
function recommendCourse(){

let completedCourses = JSON.parse(localStorage.getItem("completedCourses")) || []

let rec = document.getElementById("recommendation")

if(!rec) return

switch(completedCourses.length){

case 0:
rec.innerText = "Recommended: Start with HTML Course"
break

case 1:
rec.innerText = "Recommended: Continue with JavaScript Course"
break

case 2:
rec.innerText = "Recommended: Learn Git Basics"
break

default:
rec.innerText = "All courses completed 🎉"

}

}
function toggleReadMore(btn){

  let card = btn.parentElement;

  let short = card.querySelector(".short");
  let fullElements = card.querySelectorAll(".full");

  if(fullElements[0].style.display === "none" || fullElements[0].style.display === ""){

    short.style.display = "none";

    fullElements.forEach(el => {
      el.style.display = "block";
    });

    btn.innerText = "Read Less";

  } else {

    short.style.display = "block";

    fullElements.forEach(el => {
      el.style.display = "none";
    });

    btn.innerText = "Read More";
  }
}
document.addEventListener("DOMContentLoaded", function(){

recommendCourse();

// ONLY run if Courses page elements exist
if(document.getElementById("jsBtn")){
unlockCourses();
}

});
