// ---------------- quiz logic ----------------

// calculate percentage
function calculatePercentage(score, total){
  return Math.round((score / total) * 100);
}

// pass / fail
function isPassed(percent){
  return percent >= 40;
}

// grade calculation
function calculateGrade(percent){
  if(percent >= 80) return "A";
  else if(percent >= 60) return "B";
  else if(percent >= 40) return "C";
  else return "Fail";
}


// ---------------- quiz rendering ----------------

// render quiz dynamically
function renderQuiz(){
  let course = localStorage.getItem("currentCourse");
  let questions = quizData[course];

  let container = document.getElementById("quizContainer");
  if(!container || !questions) return;

  container.innerHTML = "";

  questions.forEach((q, index) => {

    let div = document.createElement("div");

    div.innerHTML = `<h4>${q.question}</h4>`;

    q.options.forEach((opt, i) => {
      div.innerHTML += `
        <label>
          <input type="radio" name="q${index}" value="${i}" onchange="handleOptionChange()">
          ${opt}
        </label><br>
      `;
    });

    container.appendChild(div);
  });
}

function handleOptionChange(){
  document.getElementById("questionProgress").innerText = "Answer Selected ✅";
}
// async loading simulation
async function loadQuiz(){

  let course = localStorage.getItem("currentCourse");

  let loading = document.getElementById("loading");
  let title = document.getElementById("courseTitle");

  if(title){
    title.innerText = course + " Quiz";
  }

  if(loading){
    loading.style.display = "block";
  }

  await new Promise(resolve => setTimeout(resolve, 1000));

  if(loading){
    loading.style.display = "none";
  }

  renderQuiz();

  startTimer();
}
// ---------------- timer ----------------

function startTimer(){

  let time = 30;
  let timerEl = document.getElementById("timer");

  if(!timerEl) return;

    window.quizTimer = setInterval(() => {

    time--;
    timerEl.innerText = "Time: " + time;

    if(time <= 0){
      clearInterval(  window.quizTimer);
      alert("Time's up! Submitting quiz...");

      submitQuiz(); // auto submit
    }

  }, 1000);
}

//submit Quiz
function submitQuiz(){
  if(document.getElementById("submitBtn")?.disabled) return;
    clearInterval(window.quizTimer);

  let course = localStorage.getItem("currentCourse");
  let questions = quizData[course];

  // error handling
  if(!questions){
    alert("No quiz found!");
    return;
  }

  let score = 0;         
  let answered = false;

  questions.forEach((q, index) => {

    let selected = document.querySelector(`input[name="q${index}"]:checked`);

    if(selected){
      answered = true;
    }

    if(selected && parseInt(selected.value) === q.answer){
      score++;   // 
    }
  });

  // validation
  if(!answered){
    alert("Please answer at least one question!");
    return;
  }
let submitBtn = document.getElementById("submitBtn");
if(submitBtn){
  submitBtn.disabled = true;
  submitBtn.innerText = "Submitted ✔";
}
  let percent = calculatePercentage(score, questions.length);
  let grade = calculateGrade(percent);
  let passed = isPassed(percent);

  // store progress ONLY if passed
  if(passed){

    let completed = parseInt(localStorage.getItem("quizScore")) || 0;

    if(completed < 3){
      completed++;
      localStorage.setItem("quizScore", completed);
    }

    let completedCourses = JSON.parse(localStorage.getItem("completedCourses")) || [];

    if(!completedCourses.includes(course)){
      completedCourses.push(course);
      localStorage.setItem("completedCourses", JSON.stringify(completedCourses));
    }
  }

  // message
  let message = "";

  switch(true){
    case percent >= 80:
      message = "Excellent Performance 🚀";
      break;
    case percent >= 60:
      message = "Good Job 👍";
      break;
    case percent >= 40:
      message = "You Passed 🙂";
      break;
    default:
      message = "Try Again ❌";
  }

  let nextBtn = "";

if(passed){
  if(course === "HTML"){
  nextBtn = `<br><button class="btn btn-success mt-2" onclick="goToNextCourse('JavaScript')">Next: JavaScript →</button>`;
}
else if(course === "JavaScript"){
  nextBtn = `<br><button class="btn btn-success mt-2" onclick="goToNextCourse('Git')">Next: Git →</button>`;
}
else if(course === "Git"){
  nextBtn = `<br><button class="btn btn-warning mt-2" onclick="window.location.href='profile.html'">View Certificate 🎉</button>`;
}
}

document.getElementById("result").innerHTML =
  `Score: ${percent}% | Grade: ${grade} | ${message} | ${passed ? "Passed ✅" : "Failed ❌"} ${nextBtn}`;
  
}
// ---------------- navigation ----------------

function startQuiz(course){
  localStorage.setItem("currentCourse", course);
  window.location.href = "quiz.html";
}
function goToNextCourse(course){
  localStorage.setItem("currentCourse", course);
  window.location.href = "quiz.html";
}

// ---------------- dashboard ----------------

function loadDashboard(){

  let completed = parseInt(localStorage.getItem("quizScore")) || 0;
  let percent = (completed / 3) * 100;

  let progress = document.getElementById("courseProgress");

  if(progress){

    let value = 0;

    progressInterval = setInterval(()=>{

      if(value >= percent){
        clearInterval( progressInterval);
      } else {
        value++;
        progress.value = value;
      }

    }, 20);
  }

  let text = document.getElementById("progressText");

  if(text){
    text.innerText = "Progress: " + percent + "%";
  }
}


// ---------------- profile ----------------

function loadProfile(){

  let score = localStorage.getItem("quizScore") || 0;

  let profileScore = document.getElementById("profileScore");

  if(profileScore){
    profileScore.innerText = score;
  }

  let completedCourses = JSON.parse(localStorage.getItem("completedCourses")) || [];

  let list = document.getElementById("completedList");

  if(list){

    list.innerHTML = "";

    if(completedCourses.length === 0){
      list.innerHTML = "<li>No courses completed yet</li>";
      return;
    }

    completedCourses.forEach(course => {

      let li = document.createElement("li");
      li.innerText = "Completed: " + course;

      list.appendChild(li);
    });

    if(completedCourses.length === 3){
      let msg = document.createElement("p");
      msg.innerText = "All courses completed 🎉";
      list.appendChild(msg);
    }
  }
}


// ---------------- reset ----------------

function resetProgress(){
  localStorage.clear();
  alert("Progress reset");
  window.location.reload();
}


// ---------------- certificate ----------------

function generateCertificate(){

  let completedCourses = JSON.parse(localStorage.getItem("completedCourses")) || [];

  if(completedCourses.length < 3){
    alert("Complete all courses to download certificate");
    return;
  }

  const { jsPDF } = window.jspdf;

  let doc = new jsPDF();

  // Border
  doc.setDrawColor(0);
  doc.setLineWidth(1.5);
  doc.rect(10, 10, 190, 277);

  // Title
  doc.setFont("helvetica", "bold");
  doc.setFontSize(24);
  doc.text("CERTIFICATE OF COMPLETION", 30, 40);

  // Subtitle
  doc.setFontSize(14);
  doc.setFont("helvetica", "normal");
  doc.text("This is to certify that", 70, 70);

  // Name
  doc.setFontSize(18);
  doc.setFont("helvetica", "bold");
  doc.text("Learner", 85, 85);

  // Course text
  doc.setFontSize(14);
  doc.setFont("helvetica", "normal");
  doc.text("has successfully completed the courses:", 40, 105);

  // Course list
  doc.setFont("helvetica", "bold");
  doc.text(completedCourses.join(", "), 30, 120);

  // Footer
  doc.setFontSize(12);
  doc.setFont("helvetica", "italic");
  doc.text("E-Learning Platform", 75, 160);

  doc.text("Date: " + new Date().toLocaleDateString(), 70, 175);

  doc.save("certificate.pdf");
}

// ---------------- dom ready ----------------

document.addEventListener("DOMContentLoaded", function(){

  let toggle = document.getElementById("darkToggle");

  // dark mode toggle
  if(toggle){
    toggle.addEventListener("click", () => {
      document.body.classList.toggle("dark-mode");

      localStorage.setItem("darkMode",
        document.body.classList.contains("dark-mode")
      );
    });
  }

  // load saved mode
  if(localStorage.getItem("darkMode") === "true"){
    document.body.classList.add("dark-mode");
  }

  // run only where needed
  if(document.getElementById("quizContainer")){
    loadQuiz(); //
  }

  if(document.getElementById("courseProgress")){
    loadDashboard();
  }

  if(document.getElementById("profileScore")){
    loadProfile();
  }

  // submit button event
  let submitBtn = document.getElementById("submitBtn");
  if(submitBtn){
    submitBtn.addEventListener("click", submitQuiz);
  }

  // certificate button event
  let certBtn = document.getElementById("downloadCert");
  if(certBtn){
    certBtn.addEventListener("click", generateCertificate);
  }

});


// export for testing
if (typeof module !== "undefined") {
  module.exports = { calculateGrade, calculatePercentage, isPassed };
}