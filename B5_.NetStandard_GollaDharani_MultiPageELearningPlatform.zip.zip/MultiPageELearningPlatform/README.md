# E-Learning Platform

## Project Description

This is a simple E-Learning web application built using HTML, CSS, and JavaScript.  
Users can take quizzes, track their progress, unlock courses step-by-step, and download a completion certificate.

---

## Features

- Course-based quizzes (HTML, JavaScript, Git)
- Timer-based quiz with auto submission when time ends
- Score, grade, and pass/fail calculation
- Course unlocking based on quiz completion
- Dashboard showing learning progress
- Recommended course suggestion
- Profile page with completed courses list
- Certificate generation in PDF format
- Dark mode toggle

---

## Technologies Used

- HTML
- CSS
- JavaScript
- Bootstrap
- jsPDF

---

## How to Run

1. Open `dashboard.html` in a browser  
2. Go to Courses and start the HTML quiz  
3. Complete quizzes to unlock next courses  
4. Check progress on Dashboard  
5. View completed courses in Profile  
6. Download certificate after completing all courses  

---

## Folder Structure

- css/ → styles  
- js/ → scripts (main logic, courses, quiz data)  
- tests/ → test cases  
- HTML files → application pages  

---

## Author

Golla Dharani